#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/stat.h>

#include <md5.h>

#ifdef PERMIT_LOGIN_PASSWD
#include <pwd.h>
#if defined(AIX)
#include <userpw.h>
#elif defined(SHADOW)
#include <shadow.h>
#endif
#endif /* PERMIT_LOGIN_PASSWD */

#ifndef QMAIL_GETPW
#define QMAIL_GETPW	"/var/qmail/bin/qmail-getpw"
#endif

#ifndef CONFFILE_PREFIX
#define CONFFILE_PREFIX	".qmpop"
#endif

char **
append(char *list[], char *ap[], int num)
{
	char **newlist;
	int i;

	if(num == 0) return list;
	
	for(i = 0; list[i]; i++) {}
	newlist = malloc((i + num + 1) * sizeof(char *));
	if(newlist == 0) exit(80);
	memcpy(&newlist[0], list, i   * sizeof(char *));
	memcpy(&newlist[i], ap,   num * sizeof(char *));
	newlist[i + num] = 0;
	
	return newlist;
}

int
split(int de, char *s, int num, char *a[])
{
	int i = 0;

	if(*s == '\0') return 0;
	for(;;) {
		a[i++] = s;
		if(i == num) return i;
		for(; *s != de; s++) if(*s == '\0') return i;
		*s++ = '\0';
	}
}

int
readall(int fd, char *buf, int size)
{
	int cnt, rv;
	
	for(cnt = 0; cnt < size; cnt += rv) {
		rv = read(fd, buf + cnt, size - cnt); 
		if(rv == 0) break;
		if(rv < 0) {
			if(errno == EINTR) continue;
			else return -1;
		}
	}
	return cnt;
}

int
hex2byte(char *s)
{
	int i, a, r;

	r = 0;
	for(i = 0; i < 2; s++, i++) {
		if('0' <= *s && *s <= '9') a = *s - '0';
		else if('A' <= *s && *s <= 'F') a = *s - 'A' + 10;
		else if('a' <= *s && *s <= 'f') a = *s - 'a' + 10;
		else return 0;
		r = (r << 4) + a;
	}
	return r;
}

void
getfrompopup(char *popup[3])
{
	static char popup_data[1000];
	int rv;

	rv = readall(3, popup_data, sizeof(popup_data));
	if(rv < 0  || rv >= sizeof(popup_data)) exit(12);
	popup_data[rv] = '\0';
	if(split('\0', popup_data, 3, popup) != 3) exit(13);
	return;
}

void
execgetpw(char *local, char *getpw[6])
{
	static char getpw_data[1000];
	int pipefds[2];
	int cpid, cpstat;
	int rv;

	if(pipe(pipefds) < 0) exit(20);
	cpid = fork();
	if(cpid < 0) exit(28);
	if(cpid == 0) {
		close(0);
		close(1);
		close(3);
		close(pipefds[0]);
		if(dup2(pipefds[1], 1) < 0) exit(21);
		execl(QMAIL_GETPW, QMAIL_GETPW, local, 0);
		exit(29);
	}
	close(pipefds[1]);
	rv = readall(pipefds[0], getpw_data, sizeof(getpw_data));
	wait(&cpstat);
	if(rv < 0  || rv >= sizeof(getpw_data)) exit(22);
	getpw_data[rv] = '\0';
	if(split('\0', getpw_data, 6, getpw) != 6) exit(23);
	return;
}

void
becomeuser(char *uids, char *gids)
{
	int uid, gid;

	uid = atoi(uids);
	if(uid == 0) uid = 32767;
	gid = atoi(gids);
	if(gid == 0) gid = 32767;

	if(setgid(gid) < 0) exit(31);
	if(setuid(uid) < 0) exit(30);

	return;
}

char *
makeconffilename(char *home, char *dash, char *ext)
{
	static char conffile_data[1000];
	int sz;

	sz = strlen(home) + 1 /* "/" */
	   + strlen(CONFFILE_PREFIX) + strlen(dash) + strlen(ext);
	if(sz >= sizeof(conffile_data)) exit(40);

	strcpy(conffile_data, home);
	strcat(conffile_data, "/");
	strcat(conffile_data, CONFFILE_PREFIX);
	strcat(conffile_data, dash);
	strcat(conffile_data, ext);

	return conffile_data;
}

int
checkmode(char *filename)
{
	struct stat sb;

	if(stat(filename, &sb) < 0) return 0;
	if((sb.st_mode & 0400) == 0) return 0;
	if((sb.st_mode & 0177) != 0) return 0;

	return 1;
}

void
getconf(char *conffilename, char *conf[4])
{
	static char conf_data[1000];
	int fd, rv;

	fd = open(conffilename, O_RDONLY, 0);
	if(fd < 0) exit(50);

	rv = readall(fd, conf_data, sizeof(conf_data));
	close(fd);

	if(rv < 0  || rv >= sizeof(conf_data)) exit(52);
	conf_data[rv] = '\0';
	if(split(':', conf_data, 4, conf) != 4) exit(53);


	return;
}

#ifdef PERMIT_LOGIN_PASSWD
char *
getloginpwd(char *username)
{
#if defined(AIX)
	static struct userpw *pw;
	pw = getuserpw(username);
	if(pw == 0) exit(60);
	return pw->upw_passwd;
#elif defined(SHADOW)
	static struct spwd *pw;
	pw = getspnam(username);
	if(pw == 0) exit(61);
	return pw->sp_pwdp;
#else /* traditional style */
	static struct passwd *pw;
	pw = getpwnam(username);
	if(pw == 0) exit(62);
	return pw->pw_passwd;
#endif
}
#endif /* PERMIT_LOGIN_PASSWD */

int
checkpwd_pop(char *trial, char *pwdtype, char *pwd)
{
	if(strcmp(pwdtype, "CRYPT") == 0) {
		char *e = crypt(trial, pwd);
		if(strcmp(e, pwd) == 0) return 1;
		else return 0;
	}
	else if(strcmp(pwdtype, "RAW") == 0) {
		if(strcmp(pwd, trial) == 0) return 1;
		else return 0;
	}
	else if(strcmp(pwdtype, "OBSCURE") == 0) {
		int i;
		char b;
		for(i = 0; pwd[i * 2]; i++) {
			if(pwd[i * 2 + 1] == 0) return 0;
			b = hex2byte(&pwd[i * 2]);
			if(b != trial[i]) return 0;
		}
		if(trial[i] == 0) return 1;
		else return 0;
	}
	return 0;
}

int
checkpwd_apop(char *digest, char *timestamp, char *pwdtype, char *pwd)
{
	MD5_CTX mdc;
	unsigned char truedigest[16];
	int i;

	MD5Init(&mdc);
	MD5Update(&mdc, timestamp, strlen(timestamp));

	if(strcmp(pwdtype, "OBSCURE") == 0) {
		char b;
		for(i = 0; pwd[i * 2]; i++) {
			if(pwd[i * 2 + 1] == 0) return 0;
			b = hex2byte(&pwd[i * 2]);
			MD5Update(&mdc, &b, 1);
		}
	}
	else if(strcmp(pwdtype, "RAW") == 0) {
		MD5Update(&mdc, pwd, strlen(pwd));
	}
	else return 0;

	MD5Final(truedigest, &mdc);

	if(strlen(digest) != 32) return 0;
	for(i = 0; i < 16; i++) {
		if(truedigest[i] != hex2byte(&digest[i * 2])) return 0;
	}
	return 1;
}

void
setupenv(char *user, char *home, char *shell)
{
	extern char **environ;
	char *add[3];

	add[0] = malloc(strlen("USER=")  + strlen(user)  + 1);
	if(add[0] == 0) exit(70);
	strcpy(add[0], "USER=");
	strcat(add[0], user);

	add[1] = malloc(strlen("HOME=")  + strlen(home)  + 1);
	if(add[1] == 0) exit(71);
	strcpy(add[1], "HOME=");
	strcat(add[1], user);

	add[2] = malloc(strlen("SHELL=")  + strlen(shell)  + 1);
	if(add[2] == 0) exit(72);
	strcpy(add[2], "SHELL=");
	strcat(add[2], user);

	environ = append(environ, add, 3);

	return;
}

void
execcmd(char *defaultcmd[], char *cmd)
{
	char **args, *cmds[8];
	int num, i;

#ifdef PERMIT_ALTERNATE_COMMAND
	if(cmd[0] == '-') {
		static char *empty[1] = { 0 };
		defaultcmd = empty;
		cmd++;
	}
#endif /* PERMIT_ALTERNATE_COMMAND */

	i = strlen(cmd);
	while(i > 0 && cmd[i - 1] == '\032') i--;
	while(i > 0 && isspace(cmd[i - 1])) i--;
	cmd[i] = '\0';

	num = split(' ', cmd, sizeof(cmds) / sizeof(cmds[0]), cmds); 
	args = append(defaultcmd, cmds, num);

	execv(args[0], args);
		
	return;	/* if errors occur */
}

int
main(int argc, char *argv[])
{
	char **cmd;
	char *popup[3];
	char *getpw[6];
#ifdef PERMIT_LOGIN_PASSWD
	char *loginpwd;
#endif
	char *conffile;
	char *conf[4];
	int pwdok;

	cmd = &argv[1];

	getfrompopup(popup);

	execgetpw(popup[0], getpw);
#ifdef PERMIT_LOGIN_PASSWD
	loginpwd = getloginpwd(getpw[0]);
#endif

	becomeuser(getpw[1], getpw[2]);
	if(chdir(getpw[3]) < 0) exit(91);
	setupenv(getpw[1], getpw[2], getpw[3]);

	conffile = makeconffilename(getpw[3], getpw[4], getpw[5]);

	if(checkmode(conffile)) {
		getconf(conffile, conf);
		if(cmd[0]) cmd[1] = 0;
	}
#ifdef PERMIT_DEFAULT_LOGIN
	else if(*getpw[4] == '\0') {	/* if no dash... */
		static char empty[] = "";
		conf[0] = "POP";
		conf[1] = "LOGIN";
		conf[2] = empty;
		conf[3] = empty;
	}
#endif
	else exit(92);

#ifdef PERMIT_LOGIN_PASSWD
	if(strcmp(conf[1], "LOGIN") == 0) {
		conf[0] = "POP";
		conf[1] = "CRYPT";
		conf[2] = loginpwd;
	}
#endif

	if(strcmp(conf[0], "POP") == 0) {
		pwdok = checkpwd_pop(popup[1], conf[1], conf[2]);
	}
	else if(strcmp(conf[0], "APOP") == 0) {
		pwdok = checkpwd_apop(popup[1], popup[2], conf[1], conf[2]);
	}
	else if(strcmp(conf[0], "NO") == 0) {
		pwdok = 0;
	}
#ifdef PERMIT_NO_PASSWD
	else if(strcmp(conf[0], "YES") == 0) {
		pwdok = 1;
	}
#endif
	else pwdok = 0;

	if(pwdok == 0) exit(2);

	execcmd(cmd, conf[3]);
	return 1;	/* error */
}

/* EOF */
